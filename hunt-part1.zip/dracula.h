// dracula.h
// Interface to your "Fury of Dracula" Dracula AI
// By: TeamDracula
// Date: 1 January 2012
// Version: 1.0

void decideDraculaMove(DracView gameState);
